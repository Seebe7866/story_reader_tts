import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import '../../utils/emotion.dart';
import '../../utils/language.dart';

class ElevenLabsTts {
  static Future<Uint8List> synthesize({
    required String apiKey,
    required String voiceId,
    required String text,
    required Emotion emotion,
    required Lang lang,
    double rate = 1.0,
    double pitch = 1.0,
  }) async {
    if (apiKey.isEmpty || voiceId.isEmpty) {
      throw Exception('ElevenLabs API key/voiceId missing.');
    }
    final uri = Uri.parse('https://api.elevenlabs.io/v1/text-to-speech/$voiceId');
    final payload = {
      'text': text,
      'model_id': 'eleven_multilingual_v2',
      'voice_settings': {
        'stability': 0.4,
        'similarity_boost': 0.8,
        // These are generic "style" style cues; ElevenLabs doesn't do SSML styles the same way.
        'style': _styleFactor(emotion),
        'use_speaker_boost': TrueAsInt(true),
      }
    };

    final resp = await http.post(
      uri,
      headers: {
        'xi-api-key': apiKey,
        'accept': 'audio/mpeg',
        'Content-Type': 'application/json',
      },
      body: jsonEncode(payload),
    );
    if (resp.statusCode >= 200 && resp.statusCode < 300) {
      return resp.bodyBytes;
    }
    throw Exception('ElevenLabs TTS failed: ${resp.statusCode} ${resp.body}');
  }

  static double _styleFactor(Emotion e) {
    switch (e) {
      case Emotion.happy: return 0.8;
      case Emotion.sad: return 0.2;
      case Emotion.angry: return 0.9;
      case Emotion.fearful: return 0.7;
      case Emotion.romantic: return 0.6;
      case Emotion.funny: return 0.75;
      case Emotion.neutral: default: return 0.5;
    }
  }
}

/// Helper for encoding true as 1 in JSON, if needed.
int TrueAsInt(bool b) => b ? 1 : 0;
