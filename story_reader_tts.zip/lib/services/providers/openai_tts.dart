import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import '../../utils/emotion.dart';
import '../../utils/language.dart';

class OpenAiTts {
  // Maps our emotion to a voice preset name. Users can tweak in code as needed.
  static String _voiceFor(Lang lang, Emotion e) {
    // Pick from generic names; actual available voices may vary.
    // You can replace with your preferred voices.
    switch (lang) {
      case Lang.urdu:
        return 'verse'; // hypothetical multilingual voice
      case Lang.english:
      default:
        return 'alloy';
    }
  }

  static String _styleFor(Emotion e) {
    switch (e) {
      case Emotion.happy:
        return 'cheerful';
      case Emotion.sad:
        return 'melancholy';
      case Emotion.angry:
        return 'angry';
      case Emotion.fearful:
        return 'narration-drama';
      case Emotion.romantic:
        return 'warm';
      case Emotion.funny:
        return 'playful';
      case Emotion.neutral:
      default:
        return 'neutral';
    }
  }

  static Future<Uint8List> synthesize({
    required String apiKey,
    required String text,
    required Emotion emotion,
    required Lang lang,
    double rate = 1.0,
    double pitch = 1.0,
  }) async {
    if (apiKey.isEmpty) {
      throw Exception('OpenAI API key is missing.');
    }
    final uri = Uri.parse('https://api.openai.com/v1/audio/speech');
    final voice = _voiceFor(lang, emotion);
    final style = _styleFor(emotion);

    final body = jsonEncode({
      'model': 'gpt-4o-mini-tts',
      'input': text,
      'voice': voice,
      'format': 'mp3',
      'style': style,
      'speed': rate,
      'pitch': pitch,
    });

    final resp = await http.post(
      uri,
      headers: {
        'Authorization': 'Bearer $apiKey',
        'Content-Type': 'application/json',
      },
      body: body,
    );
    if (resp.statusCode >= 200 && resp.statusCode < 300) {
      return resp.bodyBytes;
    }
    throw Exception('OpenAI TTS failed: ${resp.statusCode} ${resp.body}');
  }
}
