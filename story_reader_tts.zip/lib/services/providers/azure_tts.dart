import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import '../../utils/emotion.dart';
import '../../utils/language.dart';

class AzureTts {
  static String _voiceFor(Lang lang) {
    // Reasonable defaults; replace with any valid Neural voice you prefer
    switch (lang) {
      case Lang.urdu:
        return 'ur-PK-AsadNeural';
      case Lang.english:
      default:
        return 'en-US-JennyNeural';
    }
  }

  static String _styleFor(Emotion e) {
    switch (e) {
      case Emotion.happy:
        return 'cheerful';
      case Emotion.sad:
        return 'sad';
      case Emotion.angry:
        return 'angry';
      case Emotion.fearful:
        return 'fearful';
      case Emotion.romantic:
        return 'affectionate';
      case Emotion.funny:
        return 'whispering'; // playful alt; not all voices support every style
      case Emotion.neutral:
      default:
        return 'general';
    }
  }

  static Future<Uint8List> synthesize({
    required String key,
    required String region,
    required String text,
    required Emotion emotion,
    required Lang lang,
    double rate = 1.0,
    double pitch = 1.0,
  }) async {
    if (key.isEmpty || region.isEmpty) {
      throw Exception('Azure Speech key/region missing.');
    }
    final endpoint = Uri.parse('https://$region.tts.speech.microsoft.com/cognitiveservices/v1');
    final voice = _voiceFor(lang);
    final style = _styleFor(emotion);

    // SSML with style, rate (%), and pitch (st)
    final ratePct = ((rate - 1.0) * 100).toStringAsFixed(0) + '%';
    final pitchSt = ((pitch - 1.0) * 2).toStringAsFixed(1) + 'st';

    final ssml = '''
<speak version="1.0" xml:lang="${lang == Lang.urdu ? 'ur-PK' : 'en-US'}" xmlns:mstts="https://www.w3.org/2001/mstts">
  <voice name="$voice">
    <mstts:express-as style="$style">
      <prosody rate="$ratePct" pitch="$pitchSt">$text</prosody>
    </mstts:express-as>
  </voice>
</speak>
''';

    final resp = await http.post(
      endpoint,
      headers: {
        'Ocp-Apim-Subscription-Key': key,
        'Content-Type': 'application/ssml+xml',
        'X-Microsoft-OutputFormat': 'audio-24khz-48kbitrate-mono-mp3',
        'User-Agent': 'story-reader-tts',
      },
      body: utf8.encode(ssml),
    );

    if (resp.statusCode >= 200 && resp.statusCode < 300) {
      return resp.bodyBytes;
    }
    throw Exception('Azure TTS failed: ${resp.statusCode} ${resp.body}');
  }
}
