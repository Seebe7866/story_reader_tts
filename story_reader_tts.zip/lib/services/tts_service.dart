import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'providers/openai_tts.dart';
import 'providers/azure_tts.dart';
import 'providers/elevenlabs_tts.dart';
import '../utils/emotion.dart';
import '../utils/language.dart';

enum TtsProvider { openai, azure, elevenlabs, device }

class TtsSettings {
  final TtsProvider provider;
  final String openAiKey;
  final String azureKey;
  final String azureRegion;
  final String elevenKey;
  final String elevenVoiceId;
  final double rate;
  final double pitch;

  const TtsSettings({
    required this.provider,
    required this.openAiKey,
    required this.azureKey,
    required this.azureRegion,
    required this.elevenKey,
    required this.elevenVoiceId,
    required this.rate,
    required this.pitch,
  });

  Map<String, dynamic> toJson() => {
        'provider': provider.name,
        'openAiKey': openAiKey,
        'azureKey': azureKey,
        'azureRegion': azureRegion,
        'elevenKey': elevenKey,
        'elevenVoiceId': elevenVoiceId,
        'rate': rate,
        'pitch': pitch,
      };

  static TtsSettings fromJson(Map<String, dynamic> j) => TtsSettings(
        provider: TtsProvider.values.firstWhere(
          (p) => p.name == (j['provider'] ?? 'device'),
          orElse: () => TtsProvider.device,
        ),
        openAiKey: j['openAiKey'] ?? '',
        azureKey: j['azureKey'] ?? '',
        azureRegion: j['azureRegion'] ?? '',
        elevenKey: j['elevenKey'] ?? '',
        elevenVoiceId: j['elevenVoiceId'] ?? '',
        rate: (j['rate'] ?? 1.0) * 1.0,
        pitch: (j['pitch'] ?? 1.0) * 1.0,
      );
}

class TtsService {
  static const _prefsKey = 'tts_settings_v1';

  static Future<void> saveSettings(TtsSettings s) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefsKey, s.toJson().toString());
  }

  static Future<TtsSettings> loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_prefsKey);
    if (raw == null) {
      return const TtsSettings(
        provider: TtsProvider.device,
        openAiKey: '',
        azureKey: '',
        azureRegion: '',
        elevenKey: '',
        elevenVoiceId: '',
        rate: 1.0,
        pitch: 1.0,
      );
    }
    // quick & safe-ish parse
    final m = _parseMap(raw);
    return TtsSettings.fromJson(m);
  }

  static Map<String, dynamic> _parseMap(String s) {
    final out = <String, dynamic>{};
    final trimmed = s.trim();
    if (!trimmed.startsWith('{') || !trimmed.endsWith('}')) return out;
    final body = trimmed.substring(1, trimmed.length - 1);
    for (final part in body.split(',')) {
      final idx = part.indexOf(':');
      if (idx <= 0) continue;
      final k = part.substring(0, idx).trim().replaceAll("'", "").replaceAll('"', '');
      final v = part.substring(idx + 1).trim();
      if (v == 'true' || v == 'false') {
        out[k] = v == 'true';
      } else if (double.tryParse(v) != null) {
        out[k] = double.parse(v);
      } else {
        out[k] = v.replaceAll("'", "").replaceAll('"', '');
      }
    }
    return out;
  }

  static Future<Uint8List> synthesize({
    required String text,
    required Emotion emotion,
    required Lang lang,
    required TtsSettings settings,
  }) async {
    switch (settings.provider) {
      case TtsProvider.openai:
        return await OpenAiTts.synthesize(
          apiKey: settings.openAiKey,
          text: text,
          emotion: emotion,
          lang: lang,
          rate: settings.rate,
          pitch: settings.pitch,
        );
      case TtsProvider.azure:
        return await AzureTts.synthesize(
          key: settings.azureKey,
          region: settings.azureRegion,
          text: text,
          emotion: emotion,
          lang: lang,
          rate: settings.rate,
          pitch: settings.pitch,
        );
      case TtsProvider.elevenlabs:
        return await ElevenLabsTts.synthesize(
          apiKey: settings.elevenKey,
          voiceId: settings.elevenVoiceId,
          text: text,
          emotion: emotion,
          lang: lang,
          rate: settings.rate,
          pitch: settings.pitch,
        );
      case TtsProvider.device:
      default:
        // The device fallback is implemented in the UI using flutter_tts (streaming not supported here).
        throw Exception('Device TTS is handled in UI. Choose a cloud provider to get audio bytes.');
    }
  }
}
