import 'dart:typed_data';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../utils/emotion.dart';
import '../utils/language.dart';
import '../services/tts_service.dart';
import '../widgets/controls.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _controller = TextEditingController();
  final _audio = AudioPlayer();
  final _flutterTts = FlutterTts();

  Emotion? _selectedEmotion;
  Lang? _selectedLang;
  TtsProvider _provider = TtsProvider.device;

  String _openAiKey = '';
  String _azureKey = '';
  String _azureRegion = '';
  String _elevenKey = '';
  String _elevenVoiceId = '';

  double _rate = 1.0;
  double _pitch = 1.0;

  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    _controller.text = prefs.getString('last_story') ?? '';
    final p = await TtsService.loadSettings();
    setState(() {
      _provider = p.provider;
      _openAiKey = p.openAiKey;
      _azureKey = p.azureKey;
      _azureRegion = p.azureRegion;
      _elevenKey = p.elevenKey;
      _elevenVoiceId = p.elevenVoiceId;
      _rate = p.rate;
      _pitch = p.pitch;
    });
  }

  Future<void> _savePrefs() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('last_story', _controller.text);
    await TtsService.saveSettings(TtsSettings(
      provider: _provider,
      openAiKey: _openAiKey,
      azureKey: _azureKey,
      azureRegion: _azureRegion,
      elevenKey: _elevenKey,
      elevenVoiceId: _elevenVoiceId,
      rate: _rate,
      pitch: _pitch,
    ));
  }

  Future<void> _speak() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;

    final lang = _selectedLang ?? detectLang(text);
    final emotion = _selectedEmotion ?? guessEmotion(text);

    await _savePrefs();
    setState(() => _isLoading = true);

    try {
      if (_provider == TtsProvider.device) {
        await _speakWithDevice(text, lang, emotion);
      } else {
        final audioBytes = await TtsService.synthesize(
          text: text,
          emotion: emotion,
          lang: lang,
          settings: TtsSettings(
            provider: _provider,
            openAiKey: _openAiKey,
            azureKey: _azureKey,
            azureRegion: _azureRegion,
            elevenKey: _elevenKey,
            elevenVoiceId: _elevenVoiceId,
            rate: _rate,
            pitch: _pitch,
          ),
        );
        await _playBytes(audioBytes);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _speakWithDevice(String text, Lang lang, Emotion emotion) async {
    await _flutterTts.stop();
    if (lang == Lang.urdu) {
      await _flutterTts.setLanguage('ur-PK'); // device must support
    } else {
      await _flutterTts.setLanguage('en-US');
    }
    await _flutterTts.setSpeechRate(_rate.clamp(0.1, 1.0));
    await _flutterTts.setPitch(_pitch.clamp(0.5, 2.0));
    await _flutterTts.speak(text);
  }

  Future<void> _playBytes(Uint8List bytes) async {
    await _audio.stop();
    await _audio.play(BytesSource(bytes));
  }

  @override
  void dispose() {
    _controller.dispose();
    _audio.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final lang = _selectedLang;
    final emotion = _selectedEmotion;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Story Reader (Urdu/English)'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => _openSettings(context),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              maxLines: 8,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Paste or write your story here (Urdu or English)...',
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<Lang?>(
                    value: lang,
                    items: [
                      const DropdownMenuItem(value: null, child: Text('Auto Language Detect')),
                      DropdownMenuItem(value: Lang.urdu, child: Text(langLabel(Lang.urdu))),
                      DropdownMenuItem(value: Lang.english, child: Text(langLabel(Lang.english))),
                    ],
                    onChanged: (v) => setState(() => _selectedLang = v),
                    decoration: const InputDecoration(labelText: 'Language'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: DropdownButtonFormField<Emotion?>(
                    value: emotion,
                    items: [
                      const DropdownMenuItem(value: null, child: Text('Auto Emotion Detect')),
                      ...Emotion.values.map((e) => DropdownMenuItem(
                            value: e,
                            child: Text(emotionLabel(e)),
                          ))
                    ],
                    onChanged: (v) => setState(() => _selectedEmotion = v),
                    decoration: const InputDecoration(labelText: 'Emotion'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isLoading ? null : _speak,
                    icon: const Icon(Icons.record_voice_over),
                    label: Text(_isLoading ? 'Generating...' : 'Read the Story'),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: () => _audio.pause(),
                  icon: const Icon(Icons.pause_circle_filled),
                  tooltip: 'Pause',
                ),
                IconButton(
                  onPressed: () => _audio.resume(),
                  icon: const Icon(Icons.play_circle_fill),
                  tooltip: 'Resume',
                ),
                IconButton(
                  onPressed: () => _audio.stop(),
                  icon: const Icon(Icons.stop_circle_outlined),
                  tooltip: 'Stop',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _openSettings(BuildContext context) async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: StatefulBuilder(
            builder: (ctx, setM) {
              return SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('TTS Provider', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<TtsProvider>(
                      value: _provider,
                      items: TtsProvider.values.map((p) => DropdownMenuItem(
                        value: p,
                        child: Text(p.name.toUpperCase()),
                      )).toList(),
                      onChanged: (v) => setM(() => _provider = v ?? TtsProvider.device),
                    ),
                    const SizedBox(height: 12),
                    if (_provider == TtsProvider.openai) ...[
                      TextField(
                        decoration: const InputDecoration(labelText: 'OpenAI API Key'),
                        onChanged: (v) => _openAiKey = v,
                      ),
                    ],
                    if (_provider == TtsProvider.azure) ...[
                      TextField(
                        decoration: const InputDecoration(labelText: 'Azure Speech Key'),
                        onChanged: (v) => _azureKey = v,
                      ),
                      TextField(
                        decoration: const InputDecoration(labelText: 'Azure Region (e.g., eastus)'),
                        onChanged: (v) => _azureRegion = v,
                      ),
                    ],
                    if (_provider == TtsProvider.elevenlabs) ...[
                      TextField(
                        decoration: const InputDecoration(labelText: 'ElevenLabs API Key'),
                        onChanged: (v) => _elevenKey = v,
                      ),
                      TextField(
                        decoration: const InputDecoration(labelText: 'ElevenLabs Voice ID'),
                        onChanged: (v) => _elevenVoiceId = v,
                      ),
                    ],
                    const SizedBox(height: 12),
                    LabeledSlider(
                      label: 'Rate',
                      value: _rate,
                      onChanged: (v) => setM(() => _rate = v),
                    ),
                    LabeledSlider(
                      label: 'Pitch',
                      value: _pitch,
                      onChanged: (v) => setM(() => _pitch = v),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        ElevatedButton.icon(
                          onPressed: () {
                            Navigator.pop(ctx);
                            _savePrefs();
                          },
                          icon: const Icon(Icons.save),
                          label: const Text('Save Settings'),
                        ),
                        const SizedBox(width: 8),
                        TextButton(
                          onPressed: () => Navigator.pop(ctx),
                          child: const Text('Close'),
                        )
                      ],
                    )
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }
}
