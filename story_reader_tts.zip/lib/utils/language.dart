enum Lang { urdu, english }

Lang detectLang(String text) {
  // If any Arabic/Urdu script character present, treat as Urdu
  final hasUrdu = RegExp(r'[\u0600-\u06FF]').hasMatch(text);
  return hasUrdu ? Lang.urdu : Lang.english;
}

String langLabel(Lang l) => l == Lang.urdu ? 'Urdu' : 'English';
