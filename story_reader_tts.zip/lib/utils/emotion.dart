enum Emotion {
  neutral,
  happy,
  sad,
  angry,
  fearful, // for horror
  romantic,
  funny,
}

String emotionLabel(Emotion e) {
  switch (e) {
    case Emotion.happy:
      return 'Happy / Cheerful';
    case Emotion.sad:
      return 'Sad';
    case Emotion.angry:
      return 'Angry';
    case Emotion.fearful:
      return 'Horror / Dramatic';
    case Emotion.romantic:
      return 'Romantic / Warm';
    case Emotion.funny:
      return 'Funny / Playful';
    case Emotion.neutral:
    default:
      return 'Neutral';
  }
}

/// Very simple keyword-based guess. Users can override in UI.
Emotion guessEmotion(String text) {
  final t = text.toLowerCase();
  // Urdu hints
  if (t.contains('خوف') || t.contains('وحشت') || t.contains('ڈر') || t.contains('ہولناک')) {
    return Emotion.fearful;
  }
  if (t.contains('محبت') || t.contains('عشق') || t.contains('رومانوی')) {
    return Emotion.romantic;
  }
  if (t.contains('غم') || t.contains('اداسی') || t.contains('رو پڑا')) {
    return Emotion.sad;
  }
  if (t.contains('غصہ') || t.contains('برہم') || t.contains('تلخ')) {
    return Emotion.angry;
  }
  if (t.contains('مزاح') || t.contains('ہنسی') || t.contains('مضحکہ')) {
    return Emotion.funny;
  }

  // English hints
  if (t.contains('horror') || t.contains('terrifying') || t.contains('fear') || t.contains('spooky') || t.contains('ghost')) {
    return Emotion.fearful;
  }
  if (t.contains('love') || t.contains('romance') || t.contains('romantic') || t.contains('tender')) {
    return Emotion.romantic;
  }
  if (t.contains('sad') || t.contains('grief') || t.contains('cry')) {
    return Emotion.sad;
  }
  if (t.contains('angry') || t.contains('furious') || t.contains('rage')) {
    return Emotion.angry;
  }
  if (t.contains('funny') || t.contains('joke') || t.contains('laugh')) {
    return Emotion.funny;
  }
  if (t.contains('happy') || t.contains('cheerful') || t.contains('joy')) {
    return Emotion.happy;
  }
  return Emotion.neutral;
}
