# Story Reader TTS (Flutter)

A bilingual (Urdu/English) story reader that **reads with emotion**. Paste any story (horror, funny, sad, etc.), the app detects language/emotion and narrates in a matching voice.

## Highlights
- 🌐 Urdu **and** English
- 😮 Emotion/styling: angry, cheerful, sad, horror (dramatic), romantic, neutral
- 🧠 Auto-detect language (Urdu vs English) and guess emotion from text (you can override)
- 🔊 TTS Providers (choose in Settings):
  - **OpenAI TTS** (model: gpt-4o-mini-tts)
  - **Azure Speech** (Neural voices + styles via SSML)
  - **ElevenLabs** (any voice ID)
  - **On-device fallback** via `flutter_tts` (no key needed, limited emotion support)
- ▶️ Play / Pause / Stop, adjustable speaking rate & pitch, save last story & settings

## Quick Start (Android APK)
1. Install Flutter SDK and Android Studio.
2. `flutter pub get`
3. (Optional) Put your API keys in the app **Settings** at runtime:
   - OpenAI API Key
   - Azure Key + Region, and select Urdu/English voices (e.g., `ur-PK-AsadNeural`, `en-US-JennyNeural`)
   - ElevenLabs API Key + Voice ID
4. Run:
   ```bash
   flutter run
   ```
   or build a release APK:
   ```bash
   flutter build apk --release
   ```

## Notes
- Some providers’ emotion/style support varies by voice/language. If a style isn’t supported, the app falls back to neutral.
- On-device `flutter_tts` is offline-friendly but has limited emotional control and Urdu quality depends on device voices.
